<?php

use App\Hash;

return [
    Hash::HASH_FILENAME
];